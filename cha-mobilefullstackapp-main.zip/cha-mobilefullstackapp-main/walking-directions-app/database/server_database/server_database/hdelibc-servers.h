#ifndef HDELIBCSERVERS
#define HDELIBCSERVERS

#include "SimpleServer.h"

#endif // !HDELIBCSERVERS
