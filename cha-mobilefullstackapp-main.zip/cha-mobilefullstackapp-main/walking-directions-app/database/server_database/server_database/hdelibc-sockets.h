#ifndef HDELIBCSOCKETS
#define HDELIBCSOCKETS

#include "SimpleSocket.h"
#include "BindingSocket.h"
#include "ListeningSocket.h"
#include "ConnectingSocket.h"

#endif // !HDELIBCSOCKETS
