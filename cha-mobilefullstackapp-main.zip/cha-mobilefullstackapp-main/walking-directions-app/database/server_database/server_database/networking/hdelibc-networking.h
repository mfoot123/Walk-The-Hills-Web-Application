#ifndef HDELIBCNETWORKING
#define HDELIBCNETWORKING

#include "Sockets/hdelibc-sockets.h"
#include "Servers/hdelibc-servers.h"

#endif // !HDELIBCNETWORKING
