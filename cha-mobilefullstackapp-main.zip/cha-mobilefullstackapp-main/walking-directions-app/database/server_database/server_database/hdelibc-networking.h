#pragma comment(lib, "Ws2_32.lib")
#ifndef HDELIBCNETWORKING
#define HDELIBCNETWORKING


#include "hdelibc-sockets.h"
#include "hdelibc-servers.h"

#endif // !HDELIBCNETWORKING
