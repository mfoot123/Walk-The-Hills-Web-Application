## Team assignments

# Past Due Assignments:

# current assignments:
Due back 9/19

    - Mitch
        - fix existing function to allow a second qurry to be made. Currently doing so causes several errors.
    
    - Adam
        - Add event handler for zoom and alllow user to set zoom.
        - try and add a current location for default location?

    - JJ
        - set a default view to see pullman city center before making a qurry.

# Upcoming and unassigned:

    - allow user to see elevation gain information
    - allow user to filter by fastestest and lowest elevation gain
    - allow user to add feedback for given rout (we don't need to do anything with the feedback yet, just recieve it)